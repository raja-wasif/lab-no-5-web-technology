const fs = require('fs');

fs.writeFileSync('test.txt', 'Hello Students');

const data = fs.readFileSync('test.txt', 'utf8');
console.log(data);
