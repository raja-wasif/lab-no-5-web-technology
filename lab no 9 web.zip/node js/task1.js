// Replace the values with your own details
let name = "Raja Wasif";
let course = "ADCS";
let university = "Air University";

console.log("Name: " + name);
console.log("Course: " + course);
console.log("University: " + university);