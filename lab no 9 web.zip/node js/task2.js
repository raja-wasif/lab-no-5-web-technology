const math = recquire('./math');
console.log("subtraction:", math.multiply(10, 5));
console.log("multuplication:", math.multiply(10, 5))