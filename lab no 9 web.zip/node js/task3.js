const fs = require('fs');
const student = "Name:Raja Wasif\ncourse: BSCS\nUniversity: Air nUniversity";
fs.writeFileSync('student.txt', student);
const data = fs.readFileSync('student.txt', 'utf-8');
console.log(data);